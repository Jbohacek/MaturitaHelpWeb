﻿use master

drop database if exists ExerciseDatabase

create database ExerciseDatabase

USE [ExerciseDatabase]
GO

CREATE TABLE [dbo].[Person] (
    [Id]        INT          NOT NULL,
    [FirstName] VARCHAR (50) NOT NULL,
    [LastName]  VARCHAR (50) NOT NULL,
    [Age]       INT          NOT NULL
);


