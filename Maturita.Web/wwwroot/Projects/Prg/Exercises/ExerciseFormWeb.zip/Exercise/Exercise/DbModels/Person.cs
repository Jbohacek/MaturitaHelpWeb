﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Exercise.DbModels
{
    public partial class Person
    {
        [Required(ErrorMessage = "Je nutne")]
        public int Id { get; set; }
        [DisplayName("Jméno")]public string FirstName { get; set; } = null!;

        [MaxLength(50)]
        [MinLength(25)]
        [EmailAddress(ErrorMessage = "Spatný mail")]
        public string LastName { get; set; } = null!;
        [Range(5,10,ErrorMessage = "Rozsah je spatny")]public int Age { get; set; }
    }
}
