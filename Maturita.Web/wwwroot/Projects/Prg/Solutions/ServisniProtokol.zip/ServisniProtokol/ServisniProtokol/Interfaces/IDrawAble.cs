﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServisniProtokol.Interfaces
{
    public interface IDrawAble
    {
        public void Draw(Graphics g);
    }
}
